
library(readxl)        
library(tidyverse)    
library(sf)
library(viridis)
#
g_map <- st_read("geoBoundaries-IND-ADM1.geojson")

mydata <- read_excel("dat_st.xlsx")

B1 <- mydata %>%
  select(stunting, state_code) %>%
  drop_na() %>%
  group_by(state_code) %>%
  summarise(
    p = mean(stunting)*100,
    .groups='drop'
  )
#
map_data <- g_map %>%
  left_join(B1, by =c('shapeISO' = 'state_code'))


label_pts <- map_data %>%
  st_make_valid() %>%
  st_point_on_surface() %>%
  mutate(p_lab = ifelse(is.na(p), "", sprintf("%.1f", p)))  # 1 decimal

ggplot(map_data) +
  geom_sf(aes(fill = p), color = "white", linewidth = 0.2) +
  geom_sf_text(
    data = label_pts,
    aes(label = p_lab),
    size = 1.6,            # adjust smaller/bigger
    color = "black"
  ) +
  scale_fill_viridis_c(
    option = "plasma",
    direction = -1,
    name = "Prevalence of stunting",
    na.value = "grey90"
  ) +
  labs(title = "Prevalence of stunting (Malnutrition) in India") +
  theme_minimal() +
  coord_sf(xlim = c(68, 98), ylim = c(6, 37), expand = FALSE)















